import './App.css';
import CountryFilter from './components/CountryFilter';
import UserFilter from './components/UserFilter'
import BookFilter from './components/BookFilter'

function App() {
  return (
    <div>
      <CountryFilter/>
      <UserFilter/>
      <BookFilter/>
    </div>
  );
}

export default App;

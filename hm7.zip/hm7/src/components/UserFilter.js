import { useState, useEffect } from "react";

function UserFilter() {
    const [search, setSearch] = useState('');
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(false);
    
    useEffect(() => {
        if (!search.trim()) {
            setUsers([]);
            return;
        }

        const timeoutId = setTimeout(async () => {
            try {
                setLoading(true);
                setError(false);
                const result = await fetch(`https://api.github.com/search/users?q=${search}`);
                if (!result.ok) throw new Error('Помилка');
                const data = await result.json();
                setUsers(data.items || []);  
            } catch(error) {
                setError(true);
                setUsers([]);
            } finally {
                setLoading(false);
            }
        }, 500)
        return () => clearTimeout(timeoutId);
    }, [search]);

    return(
        <div>
            <h3>Пошук користувачів</h3>
            <input
            type="text"
            placeholder="Введіть ім'я"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            />
            {loading && <p>Завантаження</p>}
            {error && <p style={{color: 'red'}}>Помилка</p>}

            {!loading && !error && users.length === 0 && search.trim() && (
                <p>Користувачів не знайдено</p>
            )}
            <ul>
                {users.map(user => (
                    <li key={user.id}>
                        <img src={user.avatar_url} width={25} height={25} alt='avatar'/>
                        <a href={user.html_url} target="_blank" rel="noopener noreferrer">
                            {user.login}
                        </a>
                        
                    </li>
                ))}
            </ul>
        </div>
    )
}

export default UserFilter;
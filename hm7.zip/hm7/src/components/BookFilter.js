import {useState, useEffect} from 'react';

const books = [
  { title: "1984", author: "George Orwell", genre: "Dystopian" },
  { title: "Pride and Prejudice", author: "Jane Austen", genre: "Romance" },
  { title: "To Kill a Mockingbird", author: "Harper Lee", genre: "Classic" },
  { title: "The Hobbit", author: "J.R.R. Tolkien", genre: "Fantasy" },
  { title: "The Catcher in the Rye", author: "J.D. Salinger", genre: "Coming-of-Age" },
  { title: "Brave New World", author: "Aldous Huxley", genre: "Science Fiction" },
  { title: "The Great Gatsby", author: "F. Scott Fitzgerald", genre: "Tragedy" },
  { title: "Moby Dick", author: "Herman Melville", genre: "Adventure" },
  { title: "The Lord of the Rings", author: "J.R.R. Tolkien", genre: "Fantasy" },
  { title: "Harry Potter", author: "J.K. Rowling", genre: "Fantasy" },
    ];

function BookFilter() {
    const [search, setSearch] = useState('');
    const [genre, setGenre] = useState('');
    const [debounced, setDebounced] = useState('');
    const [filtered, setFiltered] = useState(books);

    useEffect(() => {
        const id = setTimeout(() => setDebounced(search), 500);
        return () => clearTimeout(id);
    }, [search])
    useEffect(() => {
        let result = books;
        if(debounced) {
            result = result.filter(book =>
                book.title.toLowerCase().includes(debounced.toLowerCase())
            )
        }
        if(genre) {
            result = result.filter(book => book.genre === genre)
        }
        setFiltered(result);
    }, [debounced, genre])

    return(
        <div>
            <h3>Пошук по книгам</h3>
            <input
            type='text'
            placeholder='Введіть назву книги'
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            />
            <select
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
            >
                <option value=''>Виберіть жанр</option>
                <option value='Dystopian'>Утопія</option>
                <option value='Romance'>Романтика</option>
                <option value='Coming-of-Age'>Роман</option>
                <option value='Science'>Наукова фантастика</option>
                <option value='Tragedy'>Драма</option>
                <option value='Adventure'>Пригоди</option>
                <option value='Fantasy'>Фентезі</option>
            </select>

            <ul>
                {filtered.map((book, id) => (
                    <li key={id}>
                        {book.author} - {book.title} - {book.genre}
                    </li>
                ))}
            </ul>

            {filtered.length === 0 && (
                <p>Нічого не знайдено</p>
            )}
        </div>
    )
}

export default BookFilter;
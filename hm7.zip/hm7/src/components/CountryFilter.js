import {useState, useEffect} from 'react';

function CountryFilter() {
    const [countries, setCountries] = useState([]);
    const [filtered, setFiltered] = useState([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(false);

    useEffect(() => {
        const fetchCountries = async () => {
            try {
                setLoading(true);
                const result = await fetch('https://restcountries.com/v3.1/all');
                if (!result.ok) throw new Error('Помилка');
                const data = await result.json();
                setCountries(data);
                setFiltered(data);
            } catch {
                setError(true);
            } finally {
                setLoading(false);
            }
        };
        fetchCountries();
    }, []);

    useEffect(() => {
        const result = countries.filter(country =>
            country.name.common.toLowerCase().includes(search.toLowerCase())
        );
        setFiltered(result);
    }, [search, countries]);

    return(
        <div>
            <h3>Список країн</h3>
            <input
            type='text'
            placeholder='Введіть країну'
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            />
            {loading && <p>Завантаження</p>}
            {error && <p style={{color: 'red'}}>Помилка</p>}

            {!loading && !error && (
                filtered.length > 0 ? (
                    <ul>
                        {filtered.map(country => (
                            <li key={country.cca3}>
                                {country.name.common}
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>Країн не знайдено!</p>
                )
            )}
        </div>
    )

}

export default CountryFilter;
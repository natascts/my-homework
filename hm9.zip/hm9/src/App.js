import './App.css';
import ContactForm from './ContactForm';

function App() {
  return (
    <div className="App">
      <ContactForm/>
    </div>
  );
}

export default App;

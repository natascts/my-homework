import {useRef, useState, useEffect} from 'react';

function ContactForm() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const [requestType, setRequestType] = useState('');
    const [errors, setErrors] = useState({});
    const [successMessage, setSuccessMessage] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        const newErrors = {};
        if (name.trim().length < 2) {
            newErrors.name = "Ім'я має містити щонайменше 2 символи";
        }
        if (!email.includes('@')){
            newErrors.email = "Email має містити '@'";
        }
        if (message.trim().length < 10){
            newErrors.message = "Має містити щонайменше 10 символів";
        }
        if (requestType === ''){
            newErrors.requestType = "Оберіть тип запиту";
        }
        setErrors(newErrors);
        if(Object.keys(newErrors).length === 0){
            setSuccessMessage('Форма успішно надіслана');
            clearForm();
        }
    }

    useEffect(() => {
        if(successMessage){
            const timer = setTimeout(() => setSuccessMessage(''), 3000);
            return () => clearTimeout(timer);
        }
    }, {successMessage})

    const nameRef = useRef(null);
    useEffect(() => {
        nameRef.current?.focus();
    }, [])

    const clearForm = () => {
        setName('');
        setEmail('');
        setMessage('');
        setRequestType('');
        setErrors({});
        setSuccessMessage('');
        nameRef.current?.focus();
    }

    return(
        <div>
            <form onSubmit={handleSubmit}>
                <h2>Форма звʼязку</h2>
                <div>
                    <label>Ім'я</label>
                    <input
                    type='text'
                    ref={nameRef}
                    placeholder="Введіть ім'я"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    />
                    {errors.name && <p style={{color: 'red'}}>{errors.name}</p>}
                </div>
                <div>
                    <label>Email</label>
                    <input
                    type='email'
                    placeholder="Введіть електрону адресу"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    />
                    {errors.email && <p style={{color: 'red'}}>{errors.email}</p>}
                </div>
                <div>
                    <label>Повідомлення:</label>
                    <textarea
                    placeholder='Напишіть повідомлення'
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    />
                    {errors.message && <p style={{color: 'red'}}>{errors.message}</p>}
                </div>
                <div>
                    <label>Тип запиту:</label>
                    <select value={requestType} onChange={(e) => setRequestType(e.target.value)}>
                        <option value=''>Оберіть тип запиту</option>
                        <option value='Question'>Питання</option>
                        <option value='Appeal'>Скарга</option>
                        <option value='Other'>Інше</option>
                    </select>
                    {errors.requestType && <p style={{color: 'red'}}>{errors.requestType}</p>}
                </div>
                <button type='submit'>Надіслати</button>
                {(name || email || message || requestType) && (
                    <button onClick={clearForm}>Очистити форму</button>
                )}
                {successMessage && <p style={{color: 'green'}}>{successMessage}</p>}

                <h3>Ви ввели:</h3>
                <p>Ім'я: {name}</p>
                <p>Email: {email}</p>
                <p>Повідомлення: {message}</p>
                <p>Тип запиту: {requestType}</p>
            </form>
        </div>
    )


}

export default ContactForm;
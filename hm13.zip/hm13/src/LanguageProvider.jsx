import {useState} from 'react';
import { LanguageContext } from './LanguageContext';

export function LanguageProvider({children}) {
    const [language, setLanguage] = useState('ua');

    const toggleLanguage = () => {
        setLanguage((l) => (l === 'ua' ? 'en' : 'ua'));
    };
    return (
        <LanguageContext.Provider value={{language, toggleLanguage}}>
            {children}
        </LanguageContext.Provider>
    );
}
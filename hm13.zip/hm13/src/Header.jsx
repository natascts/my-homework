import { useContext } from "react";
import { ThemeContext } from "./ThemeContext";
import { UserContext } from "./UserContext";
import { LanguageContext } from './LanguageContext';
import { translations } from './translations';

function Header() {
    const {user} = useContext(UserContext);
    const {theme, toggleTheme} = useContext(ThemeContext);
    const style = {
        padding: '10px',
        backgroundColor: theme === 'light' ? '#eee' : '#333',
        color: theme === 'light' ? '#000' : '#fff'
    };
    const { language } = useContext(LanguageContext);
    const translate = translations[language];


    return (
        <header style={style}>
            <h2>{translate.headerTitle}</h2>
            <p>{translate.headerName} {user.name}</p>
            <button onClick={toggleTheme}>{translate.toggleTheme}</button>
        </header>
    );
}

export default Header;
import './App.css';
import { UserProvider } from './UserProvider';
import Profile from './Profile';
import { ThemeProvider } from './ThemeProvider';
import Header from './Header';
import { LanguageProvider } from './LanguageProvider';


function App() {
  return (
    <div>
    <LanguageProvider>
      <ThemeProvider>
        <UserProvider>
          <Header />
          <Profile />
        </UserProvider>
      </ThemeProvider>
    </LanguageProvider>
    </div>
  );
}

export default App;

import {useContext} from "react";
import { UserContext } from "./UserContext";
import { ThemeContext } from "./ThemeContext";
import { LanguageContext } from "./LanguageContext";
import { translations } from "./translations";

function Profile() {
    const {user, setUser} = useContext(UserContext);
    
    const handleChangeName = () => {
        setUser({...user, name: 'Вікторія'});
    };

    const {theme} = useContext(ThemeContext);
    const style = {
        padding: '10px',
        backgroundColor: theme === 'light' ? '#eee' : '#333',
        color: theme === 'light' ? '#000' : '#fff'
    };

    const {language, toggleLanguage} = useContext(LanguageContext);
    const translate = translations[language];

    return (
        <div style={style}>
            <h2>{translate.profileTitle}</h2>
            <p>{translate.profileEmail} {user.email}</p>
            <button onClick={handleChangeName}>{translate.handleChangeName}</button>
            <button onClick={toggleLanguage}>{translate.toggleLanguage}</button>
        </div>
    )
}

export default Profile;
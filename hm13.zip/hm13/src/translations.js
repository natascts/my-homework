export const translations = {
    ua: {
        headerTitle: 'Шапка',
        toggleTheme: 'Перемкнути тему',
        headerName: "Ім'я:",
        profileTitle: 'Профіль',
        handleChangeName: "Змінити ім'я",
        profileEmail: 'Електронна пошта:',
        toggleLanguage: 'Перемкнути мову'
    },
    en: {
        headerTitle: 'Header',
        toggleTheme: 'Switch theme',
        headerName: "Name:",
        profileTitle: 'Profile',
        handleChangeName: "Change name",
        profileEmail: 'Email:',
        toggleLanguage: 'Switch language'
    }
}
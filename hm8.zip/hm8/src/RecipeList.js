import {useState} from 'react';

function RecipeList() {
    const [recipes, setRecipes] = useState([
    { id: 1, name: 'Борщ', author: 'Баба Галя' },
    { id: 2, name: 'Паста Карбонара', author: 'Chef Marco' },
    { id: 3, name: 'Сирники', author: 'Олена з Києва' },
    { id: 4, name: 'Рамен', author: 'Takeshi Yamamoto' },
    ]);
    const [newName, setNewName] = useState('');
    const [newAuthor, setNewAuthor] = useState('');

    const handleDelete = (id) => {
        setRecipes(prev => prev.filter(recipe => recipe.id !== id));
    };

    const handleAdd = () => {
        const trimmedName = newName.trim();
        const trimmedAuthor = newAuthor.trim();
        if (!trimmedName || !trimmedAuthor) return;

        const newRecipe = {
            id: Date.now(),
            name: trimmedName,
            author: trimmedAuthor
        };
        setRecipes(prev => [...prev, newRecipe]);
        setNewName('');
        setNewAuthor('');
    };

    const handleSort = () => {
        setRecipes(prev => [...prev].sort((a, b) => a.name.localeCompare(b.name)));
    };

    const handleShuffle = () => {
        setRecipes(prev => [...prev].sort(() => Math.random() - 0.5));
    };
    return(
        <div>
            <ul>
                {recipes.map(recipe => (
                    <li key={recipe.id}>
                        <span>
                            {recipe.name} - {recipe.author}
                        </span>
                        <button onClick={() => handleDelete(recipe.id)}>Видалити</button>
                    </li>
                ))}
            </ul>
            {recipes.length === 0 && (
                <p>Немає рецептів</p>
            )}
            <div>
                <input
                type='text'
                placeholder='Введіть назву рецепта'
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                />
                <input
                type='text'
                placeholder='Введіть автора рецепта'
                value={newAuthor}
                onChange={(e) => setNewAuthor(e.target.value)}
                />
                <button onClick={handleAdd}>Додати</button>
            </div>
            <button onClick={handleSort}>Сортувати</button>
            <button onClick={handleShuffle}>Перемішати</button>
        </div>
    )
}

export default RecipeList;
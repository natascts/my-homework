import './App.css';
import RecipeList from './RecipeList';

function App() {
  return (
    <div>
        <RecipeList/>
    </div>
  );
}

export default App;

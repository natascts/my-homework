import {useParams, Link} from 'react-router-dom';
import { cities } from './cities';
import CitiesPlacesLink from './CitiesPlacesLink';

export default function CitiesPlaces() {
    const {slug} = useParams();
    const city = cities.find(c => c.slug === slug);

    return (
        <div>
            <h2>{city.name} places</h2>
            <CitiesPlacesLink places={city.places}/>  
            <div>
                <Link to={`/cities/${slug}`}>Back to city</Link>
            </div>          
        </div>
    );
}    
export const cities = [
  { slug: "kyiv", name: "Kyiv", places: ["St. Sophia Cathedral", "Andriivskyi Descent"] },
  { slug: "lviv", name: "Lviv", places: ["Rynok Square", "High Castle"] },
  { slug: "odesa", name: "Odesa", places: ["Potemkin Stairs", "Arcadia Beach"] },
  { slug: "kharkiv", name: "Kharkiv", places: ["Freedom Square", "Gorky Park"] },
  { slug: "dnipro", name: "Dnipro", places: ["Monastyrskyi Island", "Menorah"] },
];
export default function NotFound() {
    return <h2>404 - Not found</h2>
}
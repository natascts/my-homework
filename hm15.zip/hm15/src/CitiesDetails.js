import {useParams, Link, Outlet, useNavigate} from 'react-router-dom';
import { cities } from './cities';

export default function CitiesDetails() {
    const {slug} = useParams();
    const currentCity = cities.findIndex(c => c.slug === slug);
    const nextCity = (currentCity + 1) % cities.length;
    const prevCity = (currentCity - 1 + cities.length) % cities.length;
    const navigate = useNavigate();
    const handleNext = () => {
        navigate(`/cities/${cities[nextCity].slug}`);
    }
    const handlePrev = () => {
        navigate(`/cities/${cities[prevCity].slug}`);
    }
    return (
        <div>
            <h2>City details</h2>
            <nav>
                <Link to={'places'}>Places</Link>
            </nav>        
            <Outlet/> 
            <button onClick={handleNext}>Next city</button>
            <button onClick={handlePrev}>Previous city</button>
            <div>
                <Link to='/cities'>Back to list</Link>
            </div>   
        </div>
    );
}
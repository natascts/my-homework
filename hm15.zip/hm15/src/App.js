import {BrowserRouter, Routes, Route, Navigate} from 'react-router-dom';
import Home from './Home';
import CitiesList from "./CitiesList";
import CitiesDetails from './CitiesDetails';
import CitiesPlaces from './CitiesPlaces';
import NotFound from './NotFound'
import Navbar from './Navbar';
import About from './About';

function App() {
  const isLoggedIn = true;

  return (
    <div>
      <BrowserRouter>
        <Navbar/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/cities' element={<CitiesList/>}/>
          <Route path='/cities/:slug' element={<CitiesDetails/>}>
            <Route index element={<CitiesPlaces/>}/>
            <Route path='places' element={isLoggedIn ? <CitiesPlaces/> : <Navigate to='/login' replace/>}/>
          </Route>
          <Route path='/about' element={<About/>}/>
          <Route path='/not-found' element={<NotFound/>}/>
          <Route path='*' element={<Navigate to='/not-found'/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

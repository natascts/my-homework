import {Link} from 'react-router-dom';
import { cities } from './cities';
import { useState } from 'react';

export default function CitiesList() {
    const [searchCity, setSearchCity] = useState('');

    return (
        <div>
            <h2>Cities</h2>
            <input
            type='text'
            placeholder='Enter the name of the city'
            value={searchCity}
            onChange={e => setSearchCity(e.target.value)}
            />
            <ul>
                {
                    cities
                    .filter(c => c.name.toLowerCase().includes(searchCity.toLowerCase()))
                    .map(c => (
                        <li key={c.slug}>
                            {c.name} - <Link to={`/cities/${c.slug}`}>View</Link>
                        </li>
                    ))
                }
            </ul>
        </div>
    );
}


export default function CitiesPlacesLink({places}) {
    return (
    <div>
        <ul>
            {places.map((place, index)=> (
                    <li key={index}>
                        {place} 
                    </li>
            ))
            }
        </ul>
    </div>
)
}
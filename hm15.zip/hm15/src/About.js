export default function About() {
    return <h2>About project</h2>;
}
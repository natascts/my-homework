import { useState } from 'react';

function LikeDislikeButtons() {
    const [like, setLike] = useState(0);
    const [dislike, setDislike] = useState(0);

    return (
        <div>
        <h3 style={{marginLeft: '10px', marginBottom: '0'}}>Завдання 5. “Подобається / Не подобається”</h3>
        <button style={{
          margin: '10px 10px',
          padding: '10px 20px',
          fontSize: '24px',
          border: '1px solid',
          borderRadius: '6px',
          backgroundColor: '#e0f7fa'
        }} 
        onClick={() => setLike(like + 1)}>👍</button>
        <button style={{
          padding: '10px 20px',
          fontSize: '24px',
          border: '1px solid',
          borderRadius: '6px',
          backgroundColor: '#ffebee'
        }} 
        onClick={() => setDislike(dislike + 1)}>👎</button>
        <p style={{marginLeft: '10px', marginTop: '0'}}>Лайків: {like}</p>
        <p style={{marginLeft: '10px', marginTop: '0'}}>Дизлайків: {dislike}</p>
        </div>
    )
}

export default LikeDislikeButtons;
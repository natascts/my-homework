import {useState} from 'react';

function TogglePassword() {
    const [pass, setPass] = useState('');
    const [secret, setSecret] = useState(true);
    const handleChange = (e) => {
        setPass(e.target.value);
    }

    return (
        <div>
        <h3 style={{marginLeft: '10px', marginBottom: '0'}}>Завдання 4. Перемикання видимості пароля</h3>
        <input
        style={{
          padding: '8px',
          fontSize: '16px',
          borderRadius: '4px',
          border: '1px solid',
          margin: '10px 10px',
          width: '200px',
        }}
        type={secret ? 'password' : 'text'}
        placeholder='Введіть пароль'
        onChange={handleChange}
        />
        <button onClick={() => setSecret(!secret)}>{secret ? 'Показати' : 'Приховати'}</button>
        </div>
    )

}

export default TogglePassword;
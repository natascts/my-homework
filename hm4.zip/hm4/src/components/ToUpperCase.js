import { useState } from 'react';

function ToUpperCase(){
    const [text, setText] = useState('');
    const handleChange = (e) => {
        setText(e.target.value);
    }

    return (
        <div>
        <h3 style={{marginLeft: '10px', marginBottom: '0'}}>Завдання 3. Переведення тексту у ВЕЛИКІ літери</h3>
        <input
        style={{
          padding: '8px',
          fontSize: '16px',
          borderRadius: '4px',
          border: '1px solid',
          margin: '10px 10px',
          width: '200px',
        }}
        type='text'
        placeholder='Введіть щось'
        onChange={handleChange}
        />
        <p style={{marginLeft: '10px', marginTop: '0'}}>{text.toUpperCase()}</p>
        </div>
    )
}

export default ToUpperCase;
import { useState } from 'react';

function Counter() {
    const [step, setStep] = useState(0);
    const [count, setCount] = useState(0);
    const handleChange = (e) => {
        setStep(Number(e.target.value));
    }

    return (
        <div>
        <h3 style={{marginLeft: '10px', marginBottom: '0'}}>Завдання 2. Лічильник зі змінним кроком</h3>
        <input
        type='number'
        placeholder='Введіть крок лічильника'
        onChange={handleChange}
        style={{
          padding: '8px',
          fontSize: '16px',
          borderRadius: '4px',
          border: '1px solid',
          margin: '10px 10px',
          width: '200px',
        }}
        />
        <button onClick={() => setCount(count+step)}>Збільшити</button>
        <p style={{marginLeft: '10px', marginTop: '0'}}>Значення: {count}</p>
        </div>
    )
}

export default Counter;
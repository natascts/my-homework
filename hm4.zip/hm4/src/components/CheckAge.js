import { useState } from 'react';

function CheckAge(){
    const [age, setAge] = useState('');
    const handleChange = (e) => {
        setAge(e.target.value);
    }

    return (
        <>
        <h3 style={{marginTop: '10px', marginLeft: '10px', marginBottom: '0'}}>Завдання 1. Перевірка повноліття</h3>
        <input
        type="number"
        placeholder='Введіть свій вік'
        onChange={handleChange}
        style={{
          padding: '8px',
          fontSize: '16px',
          borderRadius: '4px',
          border: '1px solid',
          margin: '10px 10px',
          width: '200px',
        }}
        />
        {age && (
            <p>{age >= 18 ? 'Повнолітній' : 'Неповнолітній'}</p>
        )}
        </>
    )
}

export default CheckAge;
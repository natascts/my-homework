import CheckAge from './components/CheckAge';
import Counter from './components/Counter';
import ToUpperCase from './components/ToUpperCase';
import TogglePassword from './components/TogglePassword';
import LikeDislikeButtons from './components/LikeDislikeButtons';

function App() {
  return (
    <>
      <CheckAge/>
      <Counter/>
      <ToUpperCase/>
      <TogglePassword/>
      <LikeDislikeButtons/>
    </>
  );
}

export default App;

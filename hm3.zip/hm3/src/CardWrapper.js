function CardWrapper({children}) {
    return (
        <div style={{
            border: '2px solid',
            borderRadius: '15px',
            padding: '16px',
            margin: '12px'
          }}>
            {children}
        </div>
    )
}

export default CardWrapper;
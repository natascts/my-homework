const products = [
    {
        id: 1,
        name: 'Ноутбук',
        price: 28000,
        inStock: true
    },
    {
        id: 2,
        name: 'Навушники',
        price: 1200,
        inStock: false
    },
    {
        id: 3,
        name: 'Книга',
        price: 250,
        inStock: true
    }
]

export default products;

import CardWrapper from "./CardWrapper";

function ProductCard({ product, className}) {
    const { name, price, inStock } = product;
    let backgroundColor = !inStock ? 'gray' : 'white';

    return (
        <div className={className} style={{ backgroundColor }}>
            <CardWrapper>
                <h3>{name}</h3>
                <p><i>Ціна: {price}</i></p>
                <p>В наявності: {inStock ? 'Так' : 'Ні'}</p>
            </CardWrapper>
        </div>
    )
}
export default ProductCard;
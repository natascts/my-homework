import CardWrapper from './CardWrapper';

function ArticleCard({ title, description, author }) {
    return (
        <>
            <CardWrapper>
                <h2>{title}</h2>
                <p>{description}</p>
                <p><i>Автор: {author}</i></p>
            </CardWrapper>
        </>
    )
}

export default ArticleCard;
import './App.css';
import ArticleCard from './ArticleCard';
import AlertBox from './AlertBox';
import products from './products';
import ProductCard from './ProductCard';

function App() {
  return (
    <>
      <ArticleCard title="Node.js" description="Using JavaScript to Build High-Performance Network Programs" author="Stefan Tilkov, Steve Vinoski" />
      <ArticleCard title="BugsJS" description="Benchmark of JavaScript Bugs" author="Péter Gyimesi" />
      <AlertBox status="success" text='Дані збережено успішно!' bold = {false}/>
      <AlertBox status="error" text="Помилка при збереженні!" bold={true} />
      <AlertBox status="warning" text="Попередження при збереженні!" bold={true} />
      {products.map((product, index) => 
        <ProductCard
          key={index}
          product={product}
          className='productCard'
        />
      )}
      <p>Усього товарів: {products.length}</p>
    </>
  );
}

export default App;

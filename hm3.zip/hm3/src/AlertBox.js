import CardWrapper from "./CardWrapper";

function AlertBox({ status, text, bold }) {
    let color;

    if (status === 'success') {
        color = 'green';
    } else if (status === 'error') {
        color = 'red';
    } else if (status === 'warning'){
        color = 'orange';
    }
    
    let fontWeight = bold ? 'bold' : 'normal';

    return (
        <>
            <CardWrapper>
                <p style={{ color, fontWeight }}>{text}</p >
            </CardWrapper>
        </>
    )
}
export default AlertBox;
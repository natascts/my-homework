import './App.css';
import Timer from './Timer';

function App() {
  return (
    <div>
        <Timer/>;
    </div>
  );
}

export default App;

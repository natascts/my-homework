import {useState, useRef, useEffect} from 'react';

function Timer() {
    const [seconds, setSeconds] = useState(0);
    const timeRef = useRef(null);
    const [isPaused, setIsPaused] = useState(false);
    
    const handleStart = () => {
        if (timeRef.current) return;
        timeRef.current = setInterval(() => {
            setSeconds((second) => second + 1);
        }, 1000);
    };

    const handleStop = () => {
        clearInterval(timeRef.current);
        timeRef.current = null;
    };

    const handlePause = () => {
        if (timeRef.current) {
            handleStop();
            setIsPaused(true);
        } else {
            handleStart();
            setIsPaused(false);
        }
    };

    function formatTime(seconds) {
        const hours = Math.floor(seconds / 3600).toString().padStart(2, '0');
        const min = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        const sec = Math.floor(seconds % 60).toString().padStart(2, '0');
        return `${hours}:${min}:${sec}`
    } 

    useEffect(() => {
        if (seconds >= 60) {
            return handleStop();
        }
    }, [seconds]);

    return(
        <div>
            <p>Таймер: {formatTime(seconds)}</p>
            <button onClick={handleStart}>Старт</button>
            <button onClick={handleStop}>Стоп</button>
            <button onClick={() => setSeconds(0)}>Скинути</button>
            <button onClick={handlePause}>{isPaused === false ? 'Пауза' : 'Продовжити'}</button>
        </div>
    )
}

export default Timer;
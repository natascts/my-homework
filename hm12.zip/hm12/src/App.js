import './App.css';
import UserFilterApp from './UserFilterApp';

function App() {
  return (
    <div>
      <UserFilterApp/>
    </div>
  );
}

export default App;

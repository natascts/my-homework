import { useMemo, useState, useCallback } from "react";
import React from 'react';

const USERS = [
    { id: 1, name: 'Анна', age: 25 },
    { id: 2, name: 'Олег', age: 30 },
    { id: 3, name: 'Ірина', age: 22 },
    { id: 4, name: 'Сергій', age: 28 },
    { id: 5, name: 'Марина', age: 35 }
];

const UserItem = React.memo(function UserItem({user, onClick}) {
    console.log('Рендер імені:', user.name);
    return (
        <li>
            <button onClick={() => onClick(user)}>{user.name}</button>
        </li>
    );
});

function UserFilterApp() {
    const [search, setSearch] = useState('');
    const [sortAsc, setSortAsc] = useState(true);
    const [age, setAge] = useState(0);

    const filteredNames = useMemo(() => {
        const filtered = USERS.filter((user) => user.name.toLowerCase().includes(search.toLowerCase()) && user.age >= age)
        const sorted = filtered.slice().sort((a, b) => sortAsc ? a.age - b.age : b.age - a.age);
        return sorted;
    }, [search, sortAsc, age]);

    const handleUserClick = useCallback((user) => {
        alert(`${user.name}, ${user.age} років`);
    }, []);

    const resetFilter = () => {
        setSearch('')
        setSortAsc(true)
        setAge(0)
    };

    return (
        <div>
            <h3>Фільтр користувачів з оптимізацією</h3>
            <input
            type="text"
            placeholder="Пошук за іменем"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            />
            <input
            type="range"
            min={0}
            max={100}
            value={age}
            onChange={(e) => setAge(Number(e.target.value))}
            />
            <button onClick={() => setSortAsc(!sortAsc)}>Сортувати за віком</button>
            <button onClick={resetFilter}>Скинути фільтр</button>

            <p>Знайдено: {filteredNames.length}</p>
            <p>Мінімальний вік: {age}</p>

            <ul>
                {filteredNames.map((user) => (
                    <UserItem
                    key={user.id}
                    user = {user}
                    onClick = {handleUserClick}
                    />
                ))}
            </ul>

        </div>
    )

}

export default UserFilterApp;
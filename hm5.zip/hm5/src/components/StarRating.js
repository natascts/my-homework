import { useState } from 'react';

function StarRating() {
  const [rating, setRating] = useState(0);
  const [hovered, setHovered] = useState(0);
  const ratingTexts = {
  1: 'Жахливо',
  2: 'Погано',
  3: 'Задовільно',
  4: 'Добре',
  5: 'Відмінно'
};
  const text = hovered > 0 ? ratingTexts[hovered] : ratingTexts[rating];

  return (
    <div>
      <h3>Оцініть нас:</h3>
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          style={{
            fontSize: '2rem',
            cursor: 'pointer',
            color: star <= (hovered || rating) ? 'gold' : 'gray',
          }}
          onClick={() => setRating(star)}
          onMouseEnter={() => setHovered(star)}
          onMouseLeave={() => setHovered(0)}
        >
          ★
        </span>
      ))}
      
      <p>Ваша оцінка: {rating}</p>
      {(hovered || rating) > 0 && <p>{text}</p>}
    </div>
  );
}

export default StarRating;

import { useState } from 'react';

function TipCalculator() {
  const [amount, setAmount] = useState('');
  const [tipPercent, setTipPercent] = useState('');
  const [tipResult, setTipResult] = useState(null);
  const [people, setPeople] = useState(0);
  const [resultPerPerson, setResultPerPerson] = useState(null);

  const handleCalculate = () => {
    const amt = parseFloat(amount);
    const percent = parseFloat(tipPercent);

    if (!isNaN(amt) && !isNaN(percent) && people > 0) {
      const tip = (amt * percent) / 100;
      const total = amt + tip;
      const perPerson = total / people;
      setTipResult(tip.toFixed(2));
      setResultPerPerson(perPerson.toFixed(2));
    } else {
      setTipResult(null);
      setResultPerPerson(null);
    }
}

  return (
    <div>
      <h3>Калькулятор чайових</h3>

      <input
        type="number"
        placeholder="Сума рахунку"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />

      <input
        type="number"
        placeholder="Відсоток чайових"
        value={tipPercent}
        onChange={(e) => setTipPercent(e.target.value)}
      />

      <input
        type='number'
        placeholder='Кількость людей'
        value={people}
        onChange={(e) => setPeople(e.target.value)}
      />

      <button onClick={handleCalculate}>Обчислити</button>

      {tipResult !== null && (
        <p>Чайові: {tipResult} грн</p>
      )}
      {resultPerPerson !== null && (
        <p>Кожен платить: {resultPerPerson} грн</p>
      )}
    </div>
  );
}


export default TipCalculator;

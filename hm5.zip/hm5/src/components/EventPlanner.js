import {useState} from 'react';

function EventPlanner() {
    const [eventValue, setEventValue] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [eventDate, setEventDate] = useState();

    const handleAdd = () => {
        if (inputValue.trim() !== ''){
            setEventValue([...eventValue, { name: inputValue, date: eventDate }]);
            setInputValue('');
        }
    };

    return (
        <div>
            <div>
                <label>Назва події:</label>
                <input
                type='text'
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                />
            </div>
            <div>
                <label>Дата:</label>
                <input
                type='date'
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                />
            </div>
            <button onClick={handleAdd} type='submit'>Додати подію</button>

            <ul>
                {eventValue.map((event, index) => 
                <li key={index}>{event.date} - {event.name}</li>
                )}
            </ul>
        </div>
    )
}

export default EventPlanner;
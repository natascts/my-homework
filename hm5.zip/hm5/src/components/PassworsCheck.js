import '../App.css';
import { useState } from "react";

function PasswordCheck() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    const [checkPass, setCheckPass] = useState('');
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] =useState('');
    const [isChecked, setIsChecked] = useState(false);

    const handleSubmit = (e) => {
        e.preventDefault();
        if(pass !== checkPass){
            setError('Паролі не збігаються!');
            setSubmitted(false);
        } else {
            setError('');
            setSubmitted(true);
        }
    };

    return(
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Ім'я:</label>
                    <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    />
                </div>
                <div>
                    <label>Пароль:</label>
                    <input
                    type="password"
                    value={pass}
                    onChange={(e) => setPass(e.target.value)}
                    />
                </div>
                <div>
                    <label>Повторіть пароль:</label>
                    <input
                    type="password"
                    value={checkPass}
                    onChange={(e) => setCheckPass(e.target.value)}
                    />
                </div>
                <div>
                    <label>Я приймаю умови</label>
                    <input
                    type='checkbox'
                    checked={isChecked}
                    onChange={(e) => setIsChecked(e.target.checked)}
                    />
                </div>
                <button type="submit" disabled={!isChecked}>
                    Зареєструватися
                </button>
                {error && <p style={{color: 'red'}}>{error}</p>}
                {submitted && (
                    <div style={{margin: '10px 10px'}}>
                        <p>Ім'я: {name}</p>
                        <p>Email: {email}</p>
                        <p>Пароль: {pass}</p>
                    </div>
                )}
            </form>
        </div>
    )
}

export default PasswordCheck;
import './App.css';
import PasswordCheck from './components/PassworsCheck'
import EventPlanner from './components/EventPlanner'
import StarRating from './components/StarRating';
import TipCalculator from './components/TipCalculator'

function App() {
  return (
    <div>
      <PasswordCheck/>
      <EventPlanner/>
      <StarRating/>
      <TipCalculator/>
    </div>
  );
}

export default App;

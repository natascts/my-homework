import axios from "axios";
import { useState, useEffect } from "react";

export default function PokemonList() {
    const [pokemon, setPokemon] = useState([]);
    const [limit, setLimit] = useState(10);
    const [loadingPokemon, setLoadingPokemon] = useState(true);
    const [error, setError] = useState('');
    
    const loadPokemon = async () => {
        setLoadingPokemon(true);
        try {
            const res = await axios.get(`https://pokeapi.co/api/v2/pokemon?limit=${limit}`);
            setPokemon(res.data.results);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoadingPokemon(false);
        }
    }
    useEffect(() => {
        loadPokemon();
    }, []);
    return (
        <div>
            <h2>Pokemon list</h2>
            <input
            type="text"
            value={limit}
            onChange={(e) => setLimit(e.target.value)}
            />
            {error && <p style={{color: 'red'}}>Error: {error}</p>}
            {loadingPokemon ? (
                <p>Loading pokemon...</p>
            ) : (
                <ul>
                    {pokemon.map(pok => (
                        <li key={pok.name}>
                            {pok.name} - {pok.url}
                        </li>
                    ))}
                </ul>
            )}
            <button onClick={loadPokemon}>Reload</button>
        </div>
    )
    
}
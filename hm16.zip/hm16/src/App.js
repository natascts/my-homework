import './App.css';
import UpcomingLaunches from './UpcomingLaunches';
import PokemonList from './PokemonList';

function App() {
  return (
    <div>
      <section>
        <UpcomingLaunches/>
      </section>
      <section>
        <PokemonList/>
      </section>
    </div>
  )
}

export default App;

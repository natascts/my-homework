import {useEffect, useState} from 'react';

export default function UpcomingLaunches() {
    const [launches, setLaunches] = useState([]);
    const [loadingLaunches, setLoadingLaunches] = useState(true);
    const [error, setError] = useState('');

    const loadLaunches = async () => {
        setLoadingLaunches(true);
        try {
            const res = await fetch('https://api.spacexdata.com/v4/launches/upcoming');
            if(!res.ok) throw new Error('Failed to fetch launches');
            const data = await res.json();
            const sortedData = data.sort((a, b) => new Date(a.date_utc) - new Date(b.date_utc));
            setLaunches(sortedData);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoadingLaunches(false);
        }
    }
    useEffect(() => {    
        loadLaunches();
    }, []);

    return(
        <div>
            <h2>Upcoming launches</h2>
            {error && <p style={{color: 'red'}}>Error: {error}</p>}
            {loadingLaunches ? (
                <p>Loading launches...</p>
            ) : (
                <ul>
                    {launches.map (launch => (
                        <li key={launch.id}>
                            {launch.name} - {launch.date_utc}
                        </li>
                    ))}
                </ul>
            )}
        <button onClick={loadLaunches}>Reload</button>
        </div>
    )
}
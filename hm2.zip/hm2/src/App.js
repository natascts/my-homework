import './App.css';
import BookGallery from './BookGallery';
import books from './books';

function App() {
  return (
    <>
      <BookGallery books={books} />
    </>
  );
}

export default App;

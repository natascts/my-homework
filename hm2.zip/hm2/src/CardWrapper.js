function CardWrapper({children}) {
    return (
        <div style={{
            border: '2px solid',
            borderRadius: '15px',
            padding: '16px',
            margin: '15px',
            maxWidth: '220px',
            textAlign: 'center'
          }}>
            {children}
          </div>
    )
}

export default CardWrapper;
function BookCover({ src, alt, width=180, height=250 }) {
    return (
        <img src={src} alt={alt} width={width} height={height} />
    )
}

export default BookCover;
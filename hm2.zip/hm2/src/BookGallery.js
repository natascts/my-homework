import BookCard from "./BookCard";

function BookGallery({ books }) {
    return (
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center'}}>
            {books.length > 0 ? (
                books.map((book) => (
                    <BookCard key={book.id} book={book} />
                ))
            ) : (
                <p>Полки порожні</p>
            )}
       </div> 
    )
}

export default BookGallery;
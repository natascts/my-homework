const books = [
    {
        id: 1,
        title: 'Невидимі монстри',
        author: 'Чак Поланік',
        genre: 'Трансгресивна фантастика',
        cover: 'https://static.yakaboo.ua/media/cloudflare/product/webp/600x840/i/m/img128_1_39.jpg'
    },
    {
        id: 2,
        title: 'Містер Мерседес',
        author: 'Стівен Кінг',
        genre: 'Детектив',
        cover: 'https://static.yakaboo.ua/media/cloudflare/product/webp/600x840/i/m/img_16494.jpg'
    },
    {
        id: 3,
        title: 'У розрядженому повітрі',
        author: 'Джон Кракауер',
        genre: 'Документальна проза',
        cover: 'https://static.yakaboo.ua/media/cloudflare/product/webp/600x840/u/_/u_rozridzhenomu_povitri_cover.jpg'
    }
]

export default books;
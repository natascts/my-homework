import BookCover from "./BookCover";
import CardWrapper from "./CardWrapper";

function BookCard({ book }) {
    const { title, author, genre, cover } = book;

    return (
        <>
        <CardWrapper>
            <BookCover src={cover} alt={title}/>
            <h2>{title}</h2>
            <p>Автор: {author}</p>
            <p>Жанр: {genre}</p>
        </CardWrapper>
        </>
    )
}

export default BookCard;
import { Link } from "react-router-dom";

export default function About() {
    return (
        <div>
            <h2>Про нас</h2>
            <Link to='team'>Наша команда</Link> 
        </div>
    )
}
export default function Contact() {
    return <h2>Contact page</h2>;
}
export default function Team() {
    return <h2>Команда компанії</h2>;
}
import { Link } from "react-router-dom"

export default function NotFound() {
    return (
    <div>
        <h2>404 - Сторінку не знайдено</h2>
        <Link to='/'>На головну</Link>
    </div>
    )
}
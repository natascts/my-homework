export default function Services() {
    return <h2>Наші послуги</h2>;
}
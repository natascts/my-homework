export default function Home() {
    return <h2>Home page</h2>;
}
import './App.css';
import { Navigate, Route, Routes } from 'react-router-dom';
import Navbar from './Navbar';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import NotFound from './NotFound';
import Services from './Services';
import Team from './Team';

function App() {
  return (
    <>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/home' element={<Navigate to='/'/>}/>
        <Route path='/about' element={<About/>}>
          <Route path='team' element={<Team/>}/>
        </Route>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/services' element={<Services/>}/>
        <Route path='*' element={<NotFound/>}/>
      </Routes>
    </>
  );
}

export default App;

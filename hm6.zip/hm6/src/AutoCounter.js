import {useState, useEffect} from 'react';

function AutoCounter() {
    const [time, setTime] = useState(0);
    const [isRunning, setIsRunning] = useState(true);

    useEffect(() => {
        if (!isRunning) return;
        const id = setInterval(() => setTime(t => t + 1), 1000);
        return () => clearInterval(id);
    }, [isRunning]);

    return(
        <div>
            <h3>Таймер: {time}</h3>
            <button onClick={() => setIsRunning(false)}>Зупинити</button>
            <button onClick={() => setIsRunning(true)}>Продовжити</button>
            <button onClick={() => setTime(0)}>Скинути</button>
        </div>
    )
}

export default AutoCounter;
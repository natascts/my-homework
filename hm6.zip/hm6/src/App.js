import './App.css';
import AutoCounter from './AutoCounter';
import TodoList from './TodoList';

function App() {
  return (
    <div>
      <AutoCounter/>
      <TodoList/>
    </div>
  );
}

export default App;

import {useState, useEffect} from 'react';

function TodoList() {
    const [loading, setLoading] = useState(true);
    const [todos, setTodos] = useState(null);
    const [error, setError] = useState(false);

    const fetchTodos = async () => {
        try {
            setLoading(true);
            setError(false);
            const result = await fetch('https://jsonplaceholder.typicode.com/todos');
            if (!result.ok) throw new Error('Помилка!');
            const data = await result.json();
            setTodos(data);
        } catch (e) {
            setError(true);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        fetchTodos();
    }, []);

    if (loading) return <p>Завантаження... </p>;
    if (error) return <p>Помилка</p>

    return (
        <div>
            <ul>
                {todos.slice(0, 10).map(todo => (
                    <li key={todo.id}>
                        {todo.title} - {todo.completed ? '✅ виконано' : '🕒 не виконано'};
                    </li>
                ))}
            </ul>
            <button onClick={fetchTodos}>Оновити</button>
        </div>
    )
}

export default TodoList;